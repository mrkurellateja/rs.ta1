IRIS FLOWER CLASSIFICATION

Iris flower has three species; setosa, versicolor, and virginica, which differs according to their measurements. Now assume that you have the measurements of the iris flowers according to their species, and here your task is to train a machine learning model that can learn from the measurements of the iris species and classify them.

1.In this task, I took Iris Flower dataset and performed Logistic Regression Algorithm to make model.

2.It finally categorized flowers into species.

3.I got an accuracy of 97.37% and It demonstrates that the model I created is extremely accurate.

4.And I predicted the Species using a fresh set of data and obtained an accurate result.
